AIAgent - EulerOS 专用版本

这是专门为 EulerOS release 2.0 优化的版本。

系统要求:
- EulerOS release 2.0 或更高版本
- x86_64 或 aarch64 架构
- 基本的 C++ 运行时库

安装方法:
1. 检查依赖: ./check-euleros-deps.sh
2. 安装到系统: sudo ./install-euleros.sh
3. 运行程序: AIAgent

或者直接运行:
./run-euleros.sh

EulerOS 特定说明:
- 使用 yum 包管理器
- 支持 systemd 服务管理
- 针对国产化环境优化

版本信息:
2025-07-28 11:31:00
编译目标: EulerOS release 2.0
